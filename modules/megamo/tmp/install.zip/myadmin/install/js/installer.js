/**
 * @project    MyAdmin
 * @module     Install
 * @copyright  (c) 2011 FORIX
 * @license    http://forix.com.pl/licencja.html
 */

//tab names
var nameTab_1 = "Start";
var nameTab_2 = "Sklep";
var nameTab_3 = "Konfiguracja";
var nameTab_4 = "Licencja";
var nameTab_5 = "Instalacja";
var nameTab_6 = "Podsumowanie";

//flags
var liTime = 0;
var configOk = false;
var shopOk = false;
var domainOk = false;
var licenseOk = false;
var installOk = false;

//parameters
var selectedPlatform = "";
var shopAddress = "";

function nextTab()
{
	if(verifyStep())
	{
		showStep(step+1, 'next');
	}
}
function backTab()
{
	if (step != 7) {
		showStep(step - 1, 'back');
	}
	else {
		prepareTabs();
		showStep(1, 'back');
	} 
}

function showStep(insStep, direction)
{
	step = insStep;

	//show sheet
	$('div.sheet.shown').fadeOut('fast', function() {
		$($('div.sheet')[(step-1)]).fadeIn('slow').addClass('shown');
	}).removeClass('shown');

	//upgrade the tab
	$('#tabs li')
	.removeClass("selected")
	.removeClass("finished");


	$('#tabs li:nth-child(' + step + ')').addClass("selected");
	$('#tabs li:lt(' + (step - 1) + ')').addClass("finished");
	
	//buttons
	switch(step)
	{
	case 1 :
		$("#btnBack")
		.attr("disabled", "disabled")
		.addClass("disabled")
		.show('slow');
		$("#btnNext")
		.removeAttr("disabled")
		.removeClass("disabled")
		.show('slow');
		break;

	case 2 :
		$('#btnNext').attr({'disabled':'disabled','class':'button disabled'});
		$("#btnBack")
		.removeAttr("disabled")
		.removeClass("disabled")
		.show('slow');
		break;		

	case 3:
		systemCheck();
		$("#btnBack")
		.removeAttr("disabled")
		.removeClass("disabled")
		.show('slow');
		break;
		
	case 4 :
		$("#btnNext")
		.attr("disabled", "disabled")
		.addClass("disabled")
		.show('slow');
		break;
		
	case 5:
		preinstall();
		$("#btnBack")
		.removeAttr("disabled")
		.removeClass("disabled")
		.show('slow');
		break;

	case 6:
		installMyAdmin();
		$("#btnBack")
		.attr("disabled", "disabled")
		.addClass("disabled")
		.hide('slow');
		break;

	case 7 :
		$("#btnBack")
		.attr("disabled", "disabled")
		.addClass("disabled")
		.hide('slow');
		$("#btnNext").hide('slow');
		break;
	}
}

function verifyStep()
{
	switch (step)
	{
	case 1 :
//		showStep(2, 'next');
		return true;
		break;

	case 2 :
		return shopOk;
		break;

	case 3 :
		return configOk;
		break;

	case 4 :
		return licenseOk && domainOk;
		break;	
		
	case 5 :
		return true;
		break;	
	}

}


function verifyShop(shopType){
	
	$("div#sheet_shop > ul").slideUp("1000");

	d = new Date();
	shopOk = false;
	params = "method=shopCheck"
		+"&shopType="+shopType
		+"&t="+d.getTime();

	$.get('systemcheck.php',params, function(data) {

		$("#shopInfo").empty();

		testLists = data.getElementsByTagName('testList');
		testListRequired = testLists[0].getElementsByTagName('test');
		section = "-";
		for (i = 0; i < testListRequired.length; i++){
			if(testListRequired[i].getAttribute("result")=="true"){
				res = "ok";
				shopOk = true;
				if(testListRequired[i].getAttribute("id")=="shopPlatform"){
					selectedPlatform = testListRequired[i].getAttribute("value");
				}
				if(testListRequired[i].getAttribute("id")=="shopAddress"){
					shopAddress = testListRequired[i].getAttribute("value");
				}
			}else{
				res = "fail";
				shopOk = false;
			}

			if(section != testListRequired[i].getAttribute("section")){
				$("#shopInfo").append("<li class='section'>"+testListRequired[i].getAttribute("section")+"</li>");
				section = testListRequired[i].getAttribute("section");
			}
			$("#shopInfo").append("<li class='"+res+"'>"+testListRequired[i].getAttribute("value")+"</li>");


		}

		if (!shopOk) {
			$('#btnNext').attr({'disabled':'disabled','class':'button disabled'});
		} else {
			$("#btnNext").removeAttr('disabled');
			$('#btnNext').removeClass('disabled');
			$("input#btnNext").focus();
		}

		$("div#sheet_shop > ul").slideDown("1500");

	});
}


function systemCheck()
{

	$("#req_params").slideUp("slow").delay(3000);
	
	//$("div#sheet_require > ul").hide();

	
	params = "method=configCheck"
		+"&selectedPlatform="+selectedPlatform;

	$.get('systemcheck.php',params, function(data) {

		$("#check_dirs").empty();
		$("#check_php").empty();
		testLists = data.getElementsByTagName('testList');

		configOk = true;


		testListRequired = testLists[0].getElementsByTagName('test');
		section = "-";
		var phpOk = new Array();
		var phpFail = new Array();
		
		for (i = 0; i < testListRequired.length; i++){
			if(testListRequired[i].getAttribute("result")=="true"){
				ret = "ok";
			}else{
				ret = "fail";
				configOk = false;
			}

			if(testListRequired[i].getAttribute("set") == "DIR" && section != testListRequired[i].getAttribute("section")){
				$("#check_dirs").append("<li class='section'>"+testListRequired[i].getAttribute("section")+"</li>");
				section = testListRequired[i].getAttribute("section");
			}
			switch(testListRequired[i].getAttribute("set")){
				case "DIR":
					$("#check_dirs").append("<li class='"+ret+"'>"+testListRequired[i].getAttribute("id")+"</li>");
				break;
	
	
				case "PHP":
					if(ret=="ok"){
						phpOk.push(testListRequired[i].getAttribute("id"));
					}
					
					if(ret=="fail"){
						phpFail.push(testListRequired[i].getAttribute("id"));
					}
				break;
			}
		}
		
		if(phpOk.length > 0){
			$("#check_php").append("<li class='ok'>"+phpOk.join(", ")+"</li>");
		}
		if(phpFail.length > 0){
			$("#check_php").append("<li class='fail'>"+phpFail.join(", ")+"</li>");
		}
		
		if (!configOk) {
			$('#btnNext').attr({'disabled':'disabled','class':'button disabled'});
		} else {
			$("#btnNext").removeAttr('disabled');
			$('#btnNext').removeClass('disabled');
			$("input#btnNext").focus();
		}
		
//		$("#req_params").hide("slow");
		$("#req_params").slideDown("slow");
	}
	);
}


function registerCheck(){
	
	$("div#domainInfo").slideUp("1000");
	$("#registered").hide("slow");
	$("#unregistered").hide("slow");

	d = new Date();
	shopOk = false;
	var domainInfo = "";
	var params = "method=domainCheck"
		+"&t="+d.getTime();

	$.get('systemcheck.php',params, function(data) {

//		$("#domainInfo").empty();

		testLists = data.getElementsByTagName('testList');
		testListRequired = testLists[0].getElementsByTagName('test');
		section = "-";
		for (i = 0; i < testListRequired.length; i++){
			if(testListRequired[i].getAttribute("result")=="true"){
				res = "ok";
				domainOk = true;
			}else{
				res = "fail";
				domainOk = false;
			}
			domainInfo = testListRequired[i].getAttribute("value");
		}
		
		if(domainOk){
			$("#unregistered").hide("fast").delay(3000);
			$("#registered").show("slow");
		}
		else{
			$("#registered").hide("fast").delay(3000);
			$("#unregistered").show("slow");
		}
//		$("#domainInfo").html($("#domainInfo").html()+"<h3>"+domainInfo+"</h3>");

		$("div#domainInfo").slideDown("1500");
		
		if (domainOk && licenseOk) {
			$("#btnNext").removeAttr('disabled');
			$('#btnNext').removeClass('disabled');
			$("input#btnNext").focus();			
		} else {
			$('#btnNext').attr({'disabled':'disabled','class':'button disabled'});
		}
		

	});
}

function preinstall(){

		$("#preinstall").empty();
		
		$("#preinstall").append("<li class='section'>Adres sklepu</li>");
		$("#preinstall").append("<li class='info'>"+shopAddress+"</li>");
		
		$("#preinstall").append("<li class='section'>Platforma sklepu</li>");
		$("#preinstall").append("<li class='info'>"+selectedPlatform+"</li>");
	}


function installMyAdmin(){
	
	$("div#sheet_summary").slideUp("1000");

	installOk = false;
	failed = false;
	params = "platform="+selectedPlatform+'&litime='+liTime;
	
	$.get('install.php',params, function(data) {
		$("#summary-fail > ul").empty();

		installList = data.getElementsByTagName('install');
		installSteps = installList[0].getElementsByTagName('installstep');

		for (i = 0; i < installSteps.length; i++){
			
			if(installSteps[i].getAttribute("result")=="ok"){
				res = "ok";
				installOk = true;
			}else{
				res = "fail";
				failed = true;
				$("#summary-fail > ul").append("<li class='"+res+"'>"+installSteps[i].getAttribute("value")+"</li>");
			}
		}
		
		if (installOk && !failed) {
			$('#summary-ok').removeClass("hide").addClass("show");
			$("#btnNext").addClass("hide");
			$("#btnNext").addClass("hide");
		} else {
			$('#summary-fail').removeClass("hide").addClass("show");
			$("#btnNext").addClass("hide");
			$("#btnNext").addClass("hide");
		}
		
		$('#summary').removeClass("waiting");

		$("div#sheet_summary").slideDown("1500");

	});
}



function prepareTabs()
{
	$("#tabs")
	.empty()
	.append("<li id='tab_start' class='selected'><span class='number' >1.</span>"+nameTab_1+"</li>")
	.append("<li id='tab_require'><span class='number' >2.</span>"+nameTab_2+"</li>")
	.append("<li id='tab_db'><span class='number' >3.</span>"+nameTab_3+"</li>")
	.append("<li id='tab_licence'><span class='number' >4.</span>"+nameTab_4+"</li>")
	.append("<li id='tab_infos'><span class='number' >5.</span>"+nameTab_5+"</li>")
	.append("<li id='tab_end'><span class='number' >6.</span>"+nameTab_6+"</li>");
	$(".installerVersion").show();
}


//start
$(document).ready(
		function()
		{
			//JS check
			$("#JSFail").hide();
			$("#wrapper").show();

			$("#loader").ajaxStart(
					function()
					{
						$(this).fadeIn();
						$("#btnNext[disabled!=1], #btnBack[disabled!=1]").attr("disabled", "disabled").addClass("disabled").addClass("lockedForAjax");
					}
			);
			$("#loader").ajaxComplete(
					function()
					{
						$(this).fadeOut();
						$(".lockedForAjax").removeAttr("disabled").removeClass("disabled").removeClass("lockedForAjax");
					}
			);

			$('#btnNext').bind("click",nextTab);
			$('#btnBack').bind("click",backTab);
			$('#btnDomain').bind("click",registerCheck);
			


			$('#button_refresh_systemcheck').click(
					function(){
						systemCheck();
					}
			);

			$('#shopKqs').click(

					function()
					{
						verifyShop("shopKqs");
					}
			);
			
			$('#shopGeko').click(

					function()
					{
						verifyShop("shopGeko");
					}
			);

			$('#shopPresta').click(

					function()
					{
						verifyShop("shopPresta");
					}
			);
			$('#shopOscgold').click(

					function()
					{
						verifyShop("shopOscgold");
					}
			);
			$('#shopOscommerce').click(

					function()
					{
						verifyShop("shopOscommerce");
					}
			);

			$('#acc-license').attr('checked', false);
			$('#dec-license').attr('checked', true);
			$('#shopKqs').attr('checked', false);
			$('#shopGeko').attr('checked', false);
			$('#shopPresta').attr('checked', false);
			$('#shopOscgold').attr('checked', false);
			$('#shopOscommerce').attr('checked', false);


			prepareTabs();

			step=1;
			$("input#btnNext").focus();

//			$("#btnNext")
//			.attr("disabled", "disabled")
//			.addClass("disabled");


			$('#acc-license').click(function() {
				liTime = new Date().getTime();
				licenseOk = true;
				if(domainOk){$("#btnNext")
				.removeAttr('disabled')
				.removeClass('disabled');
				}
			});

			$('#dec-license').click(function() {
				liTime = 0;
				licenseOk = false;
				$("#btnNext")
				.attr("disabled", "disabled")
				.addClass("disabled");
			});
		}
);
